set -v

./bin/Release/net6.0/dotnetServer